using StudentServiceLib;
using static System.Formats.Asn1.AsnWriter;

namespace MyTest
{
    [TestClass]
    public class UnitTest1
    {
 
        [TestMethod]
        [DataRow(2, "Chi", 19, 9, 'A')]
        [DataRow(2, "Chi", 19, 7, 'B')]
        [DataRow(2, "Chi", 19, 6, 'C')]
        [DataRow(2, "Chi", 19, 4, 'D')]
        public void TestMethodScore(int id, String name, int age, double score, char key)
        {
            Student student = new Student();
            student.Age = age;
            student.Score = score;
            student.Name = name;
            student.Id = id;

            char letter = student.getLetterScore();
            Assert.AreEqual(key, letter);
        }


        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void CheckScroreIsValib()
        {
            Student student = new Student();
            student.Age = 13;
            student.Score = 11;
            student.Name = "Chi";
            student.Id = 500;

            
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void CheckScroreIsLower0()
        {
            Student student = new Student();
            student.Age = 13;
            student.Score = -1;
            student.Name = "Chi";
            student.Id = 500;

        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void CheckScroreIsFrom0To10()
        {
            Student student = new Student();
            student.Age = 13;
            student.Score = 8;
            student.Name = "Chi";
            student.Id = 500;

        }






    }
}